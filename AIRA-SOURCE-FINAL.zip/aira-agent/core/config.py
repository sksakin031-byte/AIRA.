"""Settings loading and validation for AIRA."""
from __future__ import annotations

import copy
import json
import os
import re
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent.parent
VERSION = "1.0.0"

DEFAULTS = {
    "language": "bn",
    "model": "gemini-2.5-flash",
    "fallback_models": ["gemini-2.5-flash-lite"],
    "api_base": "https://generativelanguage.googleapis.com/v1beta",
    "timeout_seconds": 30,
    "max_retries": 4,
    "backoff_base_seconds": 1.0,
    "backoff_max_seconds": 30.0,
    "history_limit": 20,
    "max_memory_bytes": 1048576,
    "max_file_bytes": 262144,
    "max_tool_steps": 3,
    "workspace_dir": "workspace",
    "data_dir": "data",
    "allowed_extensions": [".txt", ".md", ".py", ".json", ".csv", ".yaml", ".yml", ".toml", ".ini", ".cfg"],
}

_MODEL_RE = re.compile(r"^[A-Za-z0-9._\-]{1,80}$")


class ConfigError(ValueError):
    """Raised when settings are invalid."""


def _num(name, value, lo, hi, kinds=(int,)):
    if isinstance(value, bool) or not isinstance(value, kinds):
        raise ConfigError(f"{name}: invalid type")
    if not (lo <= value <= hi):
        raise ConfigError(f"{name}: must be between {lo} and {hi}")
    return value


def validate(raw: dict) -> dict:
    s = copy.deepcopy(DEFAULTS)
    for k, v in raw.items():
        if k in DEFAULTS:
            s[k] = v
    if s["language"] not in ("bn", "en"):
        raise ConfigError("language: must be 'bn' or 'en'")
    for key in ("model",):
        if not isinstance(s[key], str) or not _MODEL_RE.match(s[key]):
            raise ConfigError(f"{key}: invalid model name")
    fb = s["fallback_models"]
    if not isinstance(fb, list) or any(not isinstance(m, str) or not _MODEL_RE.match(m) for m in fb):
        raise ConfigError("fallback_models: must be a list of model names")
    from urllib.parse import urlsplit
    try:
        endpoint = urlsplit(s["api_base"])
        valid_endpoint = (
            endpoint.scheme == "https"
            and endpoint.hostname == "generativelanguage.googleapis.com"
            and endpoint.port in (None, 443)
            and endpoint.username is None
            and endpoint.password is None
            and endpoint.path.rstrip("/") == "/v1beta"
            and not endpoint.query
            and not endpoint.fragment
        )
    except (TypeError, ValueError):
        valid_endpoint = False

    if not valid_endpoint:
        raise ConfigError("api_base: unapproved Gemini API endpoint")
    _num("timeout_seconds", s["timeout_seconds"], 1, 300, (int, float))
    _num("max_retries", s["max_retries"], 1, 10)
    _num("backoff_base_seconds", s["backoff_base_seconds"], 0, 60, (int, float))
    _num("backoff_max_seconds", s["backoff_max_seconds"], 0, 600, (int, float))
    _num("history_limit", s["history_limit"], 1, 200)
    _num("max_memory_bytes", s["max_memory_bytes"], 65536, 64 * 1024 * 1024)
    _num("max_file_bytes", s["max_file_bytes"], 1, 5 * 1024 * 1024)
    _num("max_tool_steps", s["max_tool_steps"], 0, 8)
    exts = s["allowed_extensions"]
    if not isinstance(exts, list) or not exts or any(
        not isinstance(e, str) or not re.match(r"^\.[a-z0-9]{1,8}$", e) for e in exts
    ):
        raise ConfigError("allowed_extensions: list of lowercase extensions like '.txt'")
    for key in ("workspace_dir", "data_dir"):
        v = s[key]
        if not isinstance(v, str) or not v.strip() or "\x00" in v:
            raise ConfigError(f"{key}: invalid path")
        if not os.path.isabs(v) and ".." in PurePosixPath(v.replace("\\", "/")).parts:
            raise ConfigError(f"{key}: '..' is not allowed in relative paths")
    return s


def _resolve(base: Path, value: str) -> Path:
    p = Path(value).expanduser()
    return p if p.is_absolute() else base / p


def load_settings(path=None, overrides=None, root: Path = ROOT) -> dict:
    """Load settings: defaults < config file < overrides. Never writes anything."""
    raw: dict = {}
    cfg = path or os.environ.get("AIRA_CONFIG")
    cfg_path = Path(cfg) if cfg else root / "config" / "settings.json"
    if cfg_path.exists():
        try:
            data = json.loads(cfg_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ConfigError(f"cannot read {cfg_path}: {exc}") from exc
        if not isinstance(data, dict):
            raise ConfigError(f"{cfg_path}: top-level JSON must be an object")
        raw.update(data)
    elif cfg:
        raise ConfigError(f"config file not found: {cfg_path}")
    if overrides:
        raw.update(overrides)
    s = validate(raw)
    s["workspace_path"] = _resolve(root, s["workspace_dir"])
    s["data_path"] = _resolve(root, s["data_dir"])
    s["project_root"] = root
    return s
