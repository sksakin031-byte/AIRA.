"""Engine: wires planner, memory and executor together."""
from __future__ import annotations

from core.planner import Outcome, Planner


class Engine:
    def __init__(self, settings, client, memory, executor, registry, audit):
        self.settings, self.client, self.memory = settings, client, memory
        self.executor, self.registry, self.audit = executor, registry, audit
        self.planner = Planner(client, executor, memory, settings, registry)
        self.connection = None  # None = unchecked, else dict from diagnose()

    def ask(self, text: str) -> Outcome:
        outcome = self.planner.run(text)
        if outcome.reply:
            self.memory.add("user", text)  # persisted only after a successful turn
            self.memory.add("assistant", outcome.reply)
        return outcome

    def tool(self, name, args=None):
        return self.executor.execute(name, args)

    def ping(self) -> dict:
        self.connection = self.client.diagnose()
        self.audit.log("ping", ok=self.connection.get("ok"), kind=self.connection.get("kind"))
        return self.connection
