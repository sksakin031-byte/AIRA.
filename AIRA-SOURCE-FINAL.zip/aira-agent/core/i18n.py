"""Bengali / English messages."""
from __future__ import annotations

MESSAGES = {
    "bn": {
        "tagline": "আপনার ব্যক্তিগত AI এজেন্ট",
        "model": "মডেল", "fallback": "ফলব্যাক", "connection": "সংযোগ",
        "conn_unchecked": "যাচাই করা হয়নি (/ping চালান)",
        "conn_ok": "সংযুক্ত", "conn_fail": "ব্যর্থ",
        "key_ok": "API কী সেট আছে", "key_missing": "API কী নেই",
        "hint": "সাহায্যের জন্য /help লিখুন",
        "help_title": "কমান্ড তালিকা",
        "unknown_cmd": "অজানা কমান্ড: /{cmd}। /help দেখুন।",
        "bad_arg": "আর্গুমেন্ট সঠিক নয়। ব্যবহার: {usage}",
        "too_long": "ইনপুট খুব বড়।",
        "bye": "বিদায়! AIRA বন্ধ হচ্ছে।",
        "thinking": "ভাবছি…",
        "err": "ত্রুটি",
        "approval_title": "অনুমোদন প্রয়োজন",
        "action": "কাজ", "target": "লক্ষ্য", "details": "বিবরণ",
        "approval_prompt": "অনুমোদন দিতে 'y' বা 'হ্যাঁ' লিখুন (অন্য যেকোনো উত্তর = প্রত্যাখ্যান): ",
        "denied": "প্রত্যাখ্যাত — কোনো পরিবর্তন করা হয়নি।",
        "write_prompt": "ফাইলের বিষয়বস্তু লিখুন। শেষ করতে আলাদা লাইনে .end, বাতিল করতে .cancel লিখুন।",
        "cancelled": "বাতিল করা হয়েছে।",
        "no_key": "Gemini API কী পাওয়া যায়নি। GEMINI_API_KEY সেট করুন অথবা scripts/set_key.py চালান।",
        "lang_set": "ভাষা পরিবর্তন হয়েছে: বাংলা",
        "ok_verified": "সম্পন্ন ও যাচাইকৃত", "ok_unverified": "সম্পন্ন (যাচাইকরণ নেই)", "failed": "ব্যর্থ",
        "memory": "মেমরি", "messages": "বার্তা", "workspace": "ওয়ার্কস্পেস",
        "empty": "(খালি)", "tests_passed": "টেস্ট পাস করেছে", "tests_failed": "টেস্ট ব্যর্থ",
    },
    "en": {
        "tagline": "Your personal AI agent",
        "model": "Model", "fallback": "Fallback", "connection": "Connection",
        "conn_unchecked": "not checked (run /ping)",
        "conn_ok": "connected", "conn_fail": "failed",
        "key_ok": "API key configured", "key_missing": "API key missing",
        "hint": "Type /help for help",
        "help_title": "Commands",
        "unknown_cmd": "Unknown command: /{cmd}. See /help.",
        "bad_arg": "Invalid arguments. Usage: {usage}",
        "too_long": "Input too long.",
        "bye": "Goodbye! AIRA is shutting down.",
        "thinking": "Thinking…",
        "err": "Error",
        "approval_title": "Approval required",
        "action": "Action", "target": "Target", "details": "Details",
        "approval_prompt": "Type 'y' or 'yes' to approve (anything else = deny): ",
        "denied": "Denied — nothing was changed.",
        "write_prompt": "Enter file content. Finish with .end on its own line, or .cancel to abort.",
        "cancelled": "Cancelled.",
        "no_key": "No Gemini API key found. Set GEMINI_API_KEY or run scripts/set_key.py.",
        "lang_set": "Language set: English",
        "ok_verified": "done and verified", "ok_unverified": "done (no verification available)", "failed": "failed",
        "memory": "Memory", "messages": "messages", "workspace": "Workspace",
        "empty": "(empty)", "tests_passed": "tests passed", "tests_failed": "tests failed",
    },
}

HELP = [
    ("/help", "এই সাহায্য দেখান", "Show this help"),
    ("/status", "মডেল, কী ও মেমরির অবস্থা", "Model, key and memory status"),
    ("/ping", "Gemini সংযোগ পরীক্ষা", "Test the Gemini connection"),
    ("/tools", "উপলব্ধ টুল", "List available tools"),
    ("/history", "সাম্প্রতিক কথোপকথন", "Recent conversation"),
    ("/files [path]", "ওয়ার্কস্পেসের ফাইল তালিকা", "List workspace files"),
    ("/read <path>", "ফাইল পড়ুন", "Read a workspace file"),
    ("/write <path>", "নতুন ফাইল লিখুন (অনুমোদন লাগে)", "Write a new file (needs approval)"),
    ("/overwrite <path>", "বিদ্যমান ফাইল প্রতিস্থাপন (অনুমোদন লাগে)", "Replace an existing file (needs approval)"),
    ("/check <path>", "Python ফাইলের সিনট্যাক্স যাচাই", "Validate Python syntax"),
    ("/tree", "ওয়ার্কস্পেসের কাঠামো", "Workspace structure"),
    ("/test", "AIRA-র নিজস্ব টেস্ট চালান (অনুমোদন লাগে)", "Run AIRA's own tests (needs approval)"),
    ("/model", "মডেল তথ্য", "Model info"),
    ("/lang bn|en", "ভাষা বদলান", "Switch language"),
    ("/exit", "বের হন", "Exit"),
]

USAGE = {
    "files": "/files [path]", "read": "/read <path>", "write": "/write <path>",
    "overwrite": "/overwrite <path>", "check": "/check <path>", "lang": "/lang bn|en",
}


def t(lang: str, key: str, **kw) -> str:
    table = MESSAGES.get(lang) or MESSAGES["en"]
    text = table.get(key) or MESSAGES["en"].get(key) or key
    return text.format(**kw) if kw else text
