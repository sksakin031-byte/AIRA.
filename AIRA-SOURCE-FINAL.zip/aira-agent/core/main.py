"""AIRA terminal application."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

if __package__ in (None, ""):  # allow `python core/main.py`
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ai.gemini_client import GeminiClient, GeminiError, NoApiKey
from core import router
from core.config import ConfigError, VERSION, load_settings
from core.engine import Engine
from core.i18n import HELP, t
from memory.manager import MemoryManager
from memory.store import MemoryStore
from security.approval import Approver
from security.audit import AuditLog
from security.secrets import get_api_key, mask, redact
from tools.executor import Executor
from tools.registry import build_default_registry


def format_result(res, lang) -> str:
    if res.denied:
        return "✘ " + t(lang, "denied")
    if not res.ok:
        return f"✘ {t(lang, 'err')}: {res.error}"
    d = res.data
    if res.tool == "list_files":
        rows = [f"{e['name']}{'/' if e['type'] == 'dir' else ''}" + (f"  ({e['bytes']} B)" if "bytes" in e else "")
                for e in d["entries"]]
        return "\n".join(rows) or t(lang, "empty")
    if res.tool == "read_file":
        return d["content"]
    if res.tool == "write_file":
        mark = "verified" if res.verified else "UNVERIFIED"
        return f"✔ {d['path']} — {d['bytes']} B, sha256 {d['sha256'][:12]} [{mark}]"
    if res.tool == "validate_python":
        return f"✔ {d['path']}: OK" if d["valid"] else f"✘ {d['path']}: line {d['line']}: {d['error']}"
    if res.tool == "project_structure":
        return d["tree"]
    if res.tool == "run_tests":
        head = t(lang, "tests_passed") if d["passed"] else t(lang, "tests_failed")
        return f"{'✔' if d['passed'] else '✘'} {head}\n{d['output'][-1200:]}"
    return str(d)


class App:
    def __init__(self, engine: Engine, settings: dict, input_fn=input, output_fn=print):
        self.engine, self.settings = engine, settings
        self._in, self._out = input_fn, output_fn

    @property
    def lang(self):
        return self.settings["language"]

    def banner(self):
        s, lang = self.settings, self.lang
        key = get_api_key()
        conn = self.engine.connection
        if conn is None:
            cs = t(lang, "conn_unchecked")
        else:
            cs = t(lang, "conn_ok") if conn.get("ok") else f"{t(lang, 'conn_fail')} ({conn.get('kind')})"
        o = self._out
        o("=" * 44)
        o(f"  AIRA v{VERSION} — {t(lang, 'tagline')}")
        o("=" * 44)
        o(f"{t(lang, 'model')}: {s['model']}")
        o(f"{t(lang, 'fallback')}: {', '.join(s['fallback_models']) or '-'}")
        o(f"{t(lang, 'connection')}: {cs}")
        o(f"API: {t(lang, 'key_ok') + ' (' + mask(key) + ')' if key else t(lang, 'key_missing')}")
        o(t(lang, "hint"))

    def _help(self):
        self._out(f"== {t(self.lang, 'help_title')} ==")
        for usage, bn, en in HELP:
            self._out(f"  {usage:<20} {bn if self.lang == 'bn' else en}")

    def _status(self):
        s, lang, m = self.settings, self.lang, self.engine.memory
        self._out(f"{t(lang, 'model')}: {s['model']} | {t(lang, 'fallback')}: {', '.join(s['fallback_models']) or '-'}")
        self._out(f"API: {t(lang, 'key_ok') if get_api_key() else t(lang, 'key_missing')}")
        self._out(f"{t(lang, 'memory')}: {m.count()} {t(lang, 'messages')}" + (f" — {m.load_note}" if m.load_note else ""))
        self._out(f"{t(lang, 'workspace')}: {s['workspace_path']}")

    def _read_block(self):
        self._out(t(self.lang, "write_prompt"))
        lines = []
        while True:
            try:
                line = self._in("")
            except (EOFError, KeyboardInterrupt):
                return None
            if line.strip() == ".cancel":
                return None
            if line.strip() == ".end":
                return "\n".join(lines) + ("\n" if lines else "")
            lines.append(line)

    def handle(self, line: str) -> bool:
        """Return False to exit."""
        lang = self.lang
        cmd = router.parse(line)
        if cmd is None:
            return True
        if isinstance(cmd, router.Invalid):
            if cmd.kind == "unknown":
                self._out(t(lang, "unknown_cmd", cmd=cmd.name))
            elif cmd.kind == "long":
                self._out(t(lang, "too_long"))
            else:
                self._out(t(lang, "bad_arg", usage=cmd.usage))
            return True
        if isinstance(cmd, router.Chat):
            self._out(t(lang, "thinking"))
            try:
                outcome = self.engine.ask(cmd.text)
                self._out(outcome.reply)
            except NoApiKey:
                self._out(t(lang, "no_key"))
            except GeminiError as exc:
                self._out(f"{t(lang, 'err')}: {redact(str(exc))}")
            except OSError as exc:
                self._out(f"{t(lang, 'err')}: {redact(str(exc))}")
            return True
        n, a = cmd.name, cmd.args
        if n == "exit":
            return False
        if n == "help":
            self._help()
        elif n in ("status", "model"):
            self._status()
        elif n == "ping":
            r = self.engine.ping()
            self._out(f"{t(lang, 'conn_ok')} — {r['model']} ({r['latency']}s)" if r["ok"]
                      else f"{t(lang, 'conn_fail')} [{r['kind']}]: {r['detail']}")
        elif n == "tools":
            for d in self.engine.registry.describe():
                self._out(f"  {d['name']}({d['args']}){' [approval]' if d['needs_approval'] else ''} — {d['description']}")
        elif n == "history":
            for m in self.engine.memory.recent(10):
                self._out(f"[{m['role']}] {m['text'][:200]}")
        elif n == "lang":
            self.settings["language"] = a[0]
            self._out(t(a[0], "lang_set"))
        elif n == "files":
            self._out(format_result(self.engine.tool("list_files", {"path": a[0] if a else "."}), lang))
        elif n == "read":
            self._out(format_result(self.engine.tool("read_file", {"path": a[0]}), lang))
        elif n == "check":
            self._out(format_result(self.engine.tool("validate_python", {"path": a[0]}), lang))
        elif n == "tree":
            self._out(format_result(self.engine.tool("project_structure", {}), lang))
        elif n == "test":
            self._out(format_result(self.engine.tool("run_tests", {}), lang))
        elif n in ("write", "overwrite"):
            content = self._read_block()
            if content is None:
                self._out(t(lang, "cancelled"))
            else:
                res = self.engine.tool("write_file", {"path": a[0], "content": content, "overwrite": n == "overwrite"})
                self._out(format_result(res, lang))
        return True

    def run(self) -> int:
        self.banner()
        while True:
            try:
                line = self._in("aira> ")
            except EOFError:
                self._out("")
                break
            except KeyboardInterrupt:
                self._out("")
                break
            if not self.handle(line):
                break
        self._out(t(self.lang, "bye"))
        return 0


def build_app(settings, input_fn=input, output_fn=print, client=None, transport=None) -> App:
    data = settings["data_path"]
    audit = AuditLog(data / "audit.log")
    store = MemoryStore(data / "memory.json", settings["max_memory_bytes"])
    memory = MemoryManager(store, settings["history_limit"])
    registry = build_default_registry(settings)
    approver = Approver(input_fn, output_fn, lambda: settings["language"])
    executor = Executor(registry, approver, audit)
    if client is None:
        kw = {"transport": transport} if transport else {}
        client = GeminiClient(settings, **kw)
    engine = Engine(settings, client, memory, executor, registry, audit)
    return App(engine, settings, input_fn, output_fn)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="aira", description="AIRA personal AI agent")
    ap.add_argument("--version", action="store_true")
    ap.add_argument("--self-check", action="store_true", help="validate setup without network access")
    ap.add_argument("--config", help="path to settings.json")
    ap.add_argument("--lang", choices=["bn", "en"])
    args = ap.parse_args(argv)
    if args.version:
        print(f"AIRA {VERSION}")
        return 0
    try:
        settings = load_settings(args.config, {"language": args.lang} if args.lang else None)
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    try:
        app = build_app(settings)
    except OSError as exc:
        print(f"Startup error: {exc}", file=sys.stderr)
        return 2
    if args.self_check:
        print(f"AIRA {VERSION} self-check")
        print(f"  settings: OK (model={settings['model']})")
        print(f"  workspace: {settings['workspace_path']}")
        print(f"  data: {settings['data_path']}")
        print(f"  tools: {', '.join(app.engine.registry.names())}")
        print(f"  api key: {'configured' if get_api_key() else 'not configured (chat disabled until set)'}")
        return 0
    return app.run()


if __name__ == "__main__":
    sys.exit(main())
