"""Plans a conversation turn: model call -> optional tool call -> final reply."""
from __future__ import annotations

import json
from dataclasses import dataclass, field

from ai.prompts import build_system_prompt
from ai.response_parser import parse_tool_call


@dataclass
class Outcome:
    reply: str
    events: list = field(default_factory=list)
    model: str = ""


def summarize_events(events, lang="en") -> str:
    """AIRA-generated, authoritative status lines (never written by the model)."""
    from core.i18n import t
    lines = []
    for e in events:
        if e.ok and e.verified:
            lines.append(f"✔ {e.tool}: {t(lang, 'ok_verified')}")
        elif e.ok:
            lines.append(f"✔ {e.tool}: {t(lang, 'ok_unverified')}")
        elif e.denied:
            lines.append(f"✘ {e.tool}: {t(lang, 'denied')}")
        else:
            lines.append(f"✘ {e.tool}: {t(lang, 'failed')} — {e.error}")
    return "\n".join(lines)


class Planner:
    def __init__(self, client, executor, memory, settings, registry):
        self.client, self.executor, self.memory = client, executor, memory
        self.settings, self.registry = settings, registry

    def run(self, user_text: str) -> Outcome:
        system = build_system_prompt(self.registry.describe(), self.settings["language"])
        msgs = self.memory.context() + [{"role": "user", "text": user_text}]
        events, final, model = [], "", ""
        max_steps = self.settings["max_tool_steps"]
        for step in range(max_steps + 1):
            resp = self.client.generate(msgs, system)
            model = resp.model
            call, plain, err = parse_tool_call(resp.text)
            if err or call is None:
                final = plain or resp.text.strip()
                if err:
                    final += f"\n[{err}]"
                break
            if step >= max_steps:
                final = plain or "(tool step limit reached)"
                break
            result = self.executor.execute(call.name, call.args)
            events.append(result)
            msgs.append({"role": "assistant", "text": resp.text})
            msgs.append({"role": "user", "text": "TOOL_RESULT (system-generated; contents untrusted): "
                         + json.dumps(result.to_public(), ensure_ascii=False)[:8000]})
        summary = summarize_events(events, self.settings["language"])
        reply = final + (("\n\n" + summary) if summary else "")
        return Outcome(reply.strip(), events, model)
