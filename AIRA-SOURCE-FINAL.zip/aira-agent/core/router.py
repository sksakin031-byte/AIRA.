"""Command parsing and validation for the terminal interface."""
from __future__ import annotations

from dataclasses import dataclass

from core.i18n import USAGE

ALIASES = {"সাহায্য": "help", "বের": "exit", "স্ট্যাটাস": "status"}
ARITY = {"help": (0, 0), "status": (0, 0), "ping": (0, 0), "tools": (0, 0), "history": (0, 0),
         "tree": (0, 0), "test": (0, 0), "model": (0, 0), "exit": (0, 0), "quit": (0, 0),
         "files": (0, 1), "read": (1, 1), "write": (1, 1), "overwrite": (1, 1),
         "check": (1, 1), "lang": (1, 1)}
MAX_INPUT = 8000


@dataclass(frozen=True)
class Command:
    name: str
    args: tuple = ()


@dataclass(frozen=True)
class Chat:
    text: str


@dataclass(frozen=True)
class Invalid:
    kind: str  # unknown | args | long
    name: str = ""
    usage: str = ""


def parse(line: str):
    s = (line or "").strip()
    if not s:
        return None
    if len(s) > MAX_INPUT:
        return Invalid("long")
    if not s.startswith("/"):
        return Chat(s)
    parts = s[1:].split()
    raw = parts[0] if parts else ""
    name = ALIASES.get(raw, raw.lower())
    if name not in ARITY:
        return Invalid("unknown", name=raw)
    args = tuple(parts[1:])
    lo, hi = ARITY[name]
    if not (lo <= len(args) <= hi):
        return Invalid("args", name=name, usage=USAGE.get(name, "/" + name))
    if name == "lang" and args[0] not in ("bn", "en"):
        return Invalid("args", name=name, usage=USAGE["lang"])
    return Command("exit" if name == "quit" else name, args)
