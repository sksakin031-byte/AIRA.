# Migration

1. Back up your old project: `cp -r old-aira old-aira.backup`.
2. Unzip this release into a new folder; never into the old one.
3. Run `./setup.sh`; it creates `config/settings.json` only if absent.
4. Old conversation memory: copy the old JSON file to `data/memory.json`. Plain lists of `{role, text|content}` objects are accepted; invalid entries are skipped, and the file is rewritten in the new checksummed format on the next save.
5. Old API key: use `scripts/set_key.py`; do not copy keys into config files.
6. Move working files into `workspace/` (allowed types only).
Rollback: delete the new folder; your old project and backup are untouched.
