# Security model

- **Workspace confinement**: all file tools resolve paths via `tools/validators.py`: no absolute paths, `..`, NUL, drive letters, or symlink components; real-path containment check; reads open with `O_NOFOLLOW`.
- **File policy**: extension allow-list (`.txt .md .py .json .csv .yaml .yml .toml .ini .cfg`), UTF-8 text only, size limit (`max_file_bytes`), atomic writes, no overwrite unless explicitly requested (then a `<name>.aira-bak` copy is kept).
- **No shell, no delete**: the only subprocess is the fixed `python -m unittest discover` command with no caller arguments and the API key removed from its environment.
- **Approval**: default deny; `write_file` and `run_tests` always prompt with action and target; only the terminal user's input can approve; each request id is single-use; tool arguments cannot carry an approval flag; sensitivity is decided in `security/permissions.py`, unknown tools are rejected; if the audit log cannot be written, sensitive actions are refused.
- **Secrets**: key from `GEMINI_API_KEY` or `~/.aira/api_key` (mode 600), sent only in the `x-goog-api-key` header; audit log and error messages are redacted.
- **Prompt injection**: file contents and tool results are labelled untrusted; they cannot grant approval.
Limitations: approval is terminal-based; a compromised device or Termux session is out of scope.
