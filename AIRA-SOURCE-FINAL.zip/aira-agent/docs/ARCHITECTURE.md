# Architecture

Flow of a chat turn: `core/main.py` (CLI) → `core/router.py` (parse/validate) → `core/engine.py` → `core/planner.py` → `ai/gemini_client.py` → `ai/response_parser.py`. If the model requests a tool (```aira-tool JSON block), `tools/executor.py` validates arguments, classifies the operation via `security/permissions.py`, asks the human via `security/approval.py` for sensitive operations, runs the handler, and verifies the result (writes are read back and hash-compared). AIRA appends its own status lines (✔/✘) to the reply, so a model claim of success is never the only report. The conversation is saved to `memory/` only after a turn succeeds.

Dependency direction (no cycles): `core → ai, memory, tools, security`; `tools → security`; `security → core.i18n` only. Gemini access uses `urllib` (stdlib); the transport is injectable for offline tests.

Memory file: `data/memory.json` (format `aira-memory` v1, SHA-256 checksum, atomic replace, `.bak` of the last valid state, corrupt files renamed to `.corrupt-*`, never deleted). Legacy plain-list files load and migrate on next save.
