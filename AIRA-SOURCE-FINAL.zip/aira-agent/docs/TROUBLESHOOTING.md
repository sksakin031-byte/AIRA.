# Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "API key missing" | Run `python scripts/set_key.py` or `export GEMINI_API_KEY=...` |
| `/ping` → `auth` | Key invalid or lacks permission (HTTP 401/403/400). Not retried; replace key. |
| `/ping` → `exhausted` | Network down or service busy (429/5xx/timeouts); fallback models were tried. Check connectivity, raise `timeout_seconds`. |
| model not available (404) | Change `model`/`fallback_models` in `config/settings.json`. |
| "Configuration error" | Fix the field named in the message, or restore from `config/settings.example.json`. |
| Memory warning at startup | Corrupt file was preserved as `data/memory.json.corrupt-*`; backup restored if available. |
| Python too old | `pkg upgrade python` (3.10+ needed). |
