#!/usr/bin/env python3
"""Package the project into a clean ZIP with one top-level directory and SHA256SUMS."""
import hashlib
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOP = "aira-agent"
SKIP_DIRS = {"__pycache__", ".git", ".venv", "venv", "data", ".mypy_cache", ".pytest_cache"}
SKIP_NAMES = {"settings.json", ".env"}
SKIP_SUFFIX = (".pyc", ".bak", ".tmp", ".aira-bak")
SECRET_RES = [re.compile(r"AIza[0-9A-Za-z_\-]{30,}"), re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
              re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{20,}")]


def wanted(p: Path) -> bool:
    rel = p.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):
        return False
    if p.name in SKIP_NAMES or p.name.endswith(SKIP_SUFFIX) or ".corrupt-" in p.name:
        return False
    if rel.parts[0] == "workspace" and p.name != ".gitkeep":
        return False
    return p.is_file() and not p.is_symlink()


def main(out: str) -> int:
    files = sorted(
        p for p in ROOT.rglob("*")
        if wanted(p) and p.relative_to(ROOT).as_posix() != "SHA256SUMS"
    )
    for p in files:
        try:
            text = p.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for rx in SECRET_RES:
            if rx.search(text):
                print(f"REFUSING: secret-like content in {p.relative_to(ROOT)}", file=sys.stderr)
                return 1
    sums = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            data = p.read_bytes()
            sums.append(f"{hashlib.sha256(data).hexdigest()}  {p.relative_to(ROOT).as_posix()}")
            info = zipfile.ZipInfo(f"{TOP}/{p.relative_to(ROOT).as_posix()}", date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if p.suffix == ".sh" else 0o644) << 16
            z.writestr(info, data)
        info = zipfile.ZipInfo(f"{TOP}/SHA256SUMS", date_time=(2026, 11, 7, 0, 0, 0))
        info.external_attr = 0o644 << 16
        z.writestr(info, "\n".join(sums) + "\n")
    print(f"wrote {out} ({len(files) + 1} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "aira-professional-master.zip"))
