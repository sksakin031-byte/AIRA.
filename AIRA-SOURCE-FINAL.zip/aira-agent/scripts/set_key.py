#!/usr/bin/env python3
"""Store the Gemini API key in ~/.aira/api_key (mode 600). Asks before overwriting."""
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from security.secrets import default_key_file, store_api_key  # noqa: E402


def main() -> int:
    path = default_key_file()
    overwrite = False
    if path.exists():
        if input(f"{path} exists. Overwrite? [y/N] ").strip().lower() not in ("y", "yes"):
            print("Kept existing key.")
            return 0
        overwrite = True
    key = getpass.getpass("Gemini API key (input hidden): ")
    try:
        store_api_key(key, overwrite=overwrite)
    except (ValueError, OSError) as exc:
        print(f"Could not store key: {exc}", file=sys.stderr)
        return 1
    print(f"Saved to {path} (permissions 600).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
