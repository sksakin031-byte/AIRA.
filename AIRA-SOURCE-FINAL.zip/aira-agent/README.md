# AIRA — Personal AI Agent (Master Edition 1.0.0)

Cloud-connected (Gemini) personal AI agent for Android + Termux. Bengali and English. Pure Python standard library — no third-party packages, no root, no PC.

## Install (Termux)
```bash
pkg update && pkg install python unzip
unzip aira-professional-master.zip && cd aira-agent
./setup.sh
python scripts/set_key.py      # stores key in ~/.aira/api_key (mode 600); or: export GEMINI_API_KEY=...
```
## Start
```bash
./start.sh            # same as: python -m core.main
./start.sh --lang en  # English UI
```
## Test (offline, no key needed)
```bash
./test.sh
```
## Commands
`/help /status /ping /tools /history /files [path] /read <path> /write <path> /overwrite <path> /check <path> /tree /test /model /lang bn|en /exit`

`/write` and `/overwrite` read lines until `.end` (or `.cancel`). Every write and `/test` asks for explicit approval first. Paths cannot contain spaces.

## Configuration
`config/settings.json` (created by setup from `settings.example.json`, never overwritten). Key settings: `model`, `fallback_models`, `timeout_seconds`, `max_retries`, `history_limit`, `max_memory_bytes`, `max_file_bytes`. Override file with `--config PATH` or `AIRA_CONFIG`.

## Layout
`core/` engine, planner, router, CLI · `ai/` Gemini client, parser, prompts · `memory/` store, manager, models · `tools/` registry, executor, filesystem · `security/` approval, permissions, audit, secrets · `tests/` · `docs/`.

See `docs/ARCHITECTURE.md`, `docs/SECURITY.md`, `docs/TROUBLESHOOTING.md`, `docs/MIGRATION.md`.
