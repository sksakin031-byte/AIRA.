import json
import tempfile
import unittest
from pathlib import Path

from security import permissions
from security.approval import Approver, ApprovalRequest, DenyAllApprover
from security.audit import AuditLog, AuditError
from security.secrets import redact, store_api_key, get_api_key
from tests.helpers import FAKE_KEY, make_settings
from tools.executor import Executor
from tools.registry import Registry, Tool, build_default_registry


def build(tmp, approver):
    s = make_settings(tmp)
    audit = AuditLog(tmp / "audit.log")
    reg = build_default_registry(s)
    return s, Executor(reg, approver, audit), audit


class ApprovalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def test_default_deny_on_empty_and_eof_and_garbage(self):
        for answer in ["", "no", "maybe", "yes please!!"]:
            a = Approver(lambda p, ans=answer: ans, lambda *x: None)
            self.assertFalse(a.request(ApprovalRequest.new("x", "y")))
        def eof(_):
            raise EOFError
        self.assertFalse(Approver(eof, lambda *x: None).request(ApprovalRequest.new("x", "y")))

    def test_accepts_explicit_yes(self):
        for answer in ["y", "YES", " হ্যাঁ "]:
            a = Approver(lambda p, ans=answer: ans, lambda *x: None)
            self.assertTrue(a.request(ApprovalRequest.new("x", "y")))

    def test_request_id_cannot_be_replayed(self):
        a = Approver(lambda p: "y", lambda *x: None)
        req = ApprovalRequest.new("x", "y")
        self.assertTrue(a.request(req))
        self.assertFalse(a.request(req))

    def test_prompt_shows_action_and_target(self):
        out = []
        Approver(lambda p: "n", out.append).request(ApprovalRequest.new("write_file", "notes.txt", "bytes=3"))
        text = "\n".join(out)
        self.assertIn("write_file", text)
        self.assertIn("notes.txt", text)

    def test_sensitive_tool_denied_changes_nothing(self):
        s, ex, _ = build(self.tmp, DenyAllApprover())
        r = ex.execute("write_file", {"path": "a.txt", "content": "x"})
        self.assertFalse(r.ok)
        self.assertTrue(r.denied)
        self.assertFalse((s["workspace_path"] / "a.txt").exists())

    def test_sensitive_tool_runs_only_after_approval(self):
        s, ex, _ = build(self.tmp, Approver(lambda p: "y", lambda *x: None))
        r = ex.execute("write_file", {"path": "a.txt", "content": "x"})
        self.assertTrue(r.ok and r.verified)

    def test_ai_cannot_inject_approval_argument(self):
        s, ex, _ = build(self.tmp, DenyAllApprover())
        r = ex.execute("write_file", {"path": "a.txt", "content": "x", "approved": True})
        self.assertFalse(r.ok)
        self.assertIn("unexpected", r.error)
        self.assertFalse((s["workspace_path"] / "a.txt").exists())

    def test_approver_must_return_literal_true(self):
        class Sloppy:
            def request(self, req):
                return "yes"  # truthy but not True
        s, ex, _ = build(self.tmp, Sloppy())
        self.assertFalse(ex.execute("write_file", {"path": "a.txt", "content": "x"}).ok)

    def test_unknown_and_unclassified_tools_rejected(self):
        s, ex, _ = build(self.tmp, Approver(lambda p: "y", lambda *x: None))
        self.assertFalse(ex.execute("shell", {"cmd": "ls"}).ok)
        self.assertFalse(ex.execute(None, {}).ok)
        self.assertFalse(ex.execute("delete_file", {"path": "a.txt"}).ok)
        with self.assertRaises(ValueError):
            Registry().register(Tool("rm_rf", "bad", {}, lambda a: {}))

    def test_bad_argument_types_rejected(self):
        s, ex, _ = build(self.tmp, DenyAllApprover())
        self.assertFalse(ex.execute("read_file", {"path": 5}).ok)
        self.assertFalse(ex.execute("read_file", {}).ok)
        self.assertFalse(ex.execute("read_file", "notadict").ok)

    def test_audit_failure_blocks_sensitive_action(self):
        s = make_settings(self.tmp)
        bad_audit = AuditLog(self.tmp / "file_not_dir" / "audit.log")
        (self.tmp / "file_not_dir").write_text("x")
        ex = Executor(build_default_registry(s), Approver(lambda p: "y", lambda *x: None), bad_audit)
        r = ex.execute("write_file", {"path": "a.txt", "content": "x"})
        self.assertFalse(r.ok)
        self.assertFalse((s["workspace_path"] / "a.txt").exists())

    def test_permission_classification(self):
        self.assertEqual(permissions.classify("write_file"), "sensitive")
        self.assertEqual(permissions.classify("read_file"), "safe")
        self.assertEqual(permissions.classify("anything_else"), "unknown")


class SecretTests(unittest.TestCase):
    def test_redaction(self):
        self.assertNotIn(FAKE_KEY, redact(f"key={FAKE_KEY}"))
        self.assertNotIn("abcdef123456", redact("Authorization: Bearer abcdef123456"))
        self.assertNotIn("hunter22", redact('{"password": "hunter22"}'))

    def test_audit_log_never_contains_secret(self):
        tmp = Path(tempfile.mkdtemp())
        log = AuditLog(tmp / "a.log")
        log.log("evt", note=f"used {FAKE_KEY}", nested={"token": "tok_123456789"})
        content = (tmp / "a.log").read_text()
        self.assertNotIn(FAKE_KEY, content)
        self.assertNotIn("tok_123456789", content)
        json.loads(content.splitlines()[0])

    def test_key_file_permissions_and_no_overwrite(self):
        tmp = Path(tempfile.mkdtemp())
        p = tmp / "k" / "api_key"
        store_api_key(FAKE_KEY, p)
        self.assertEqual(p.stat().st_mode & 0o077, 0)
        with self.assertRaises(FileExistsError):
            store_api_key("other", p)
        self.assertEqual(get_api_key(p) if not __import__("os").environ.get("GEMINI_API_KEY") else FAKE_KEY, FAKE_KEY)


if __name__ == "__main__":
    unittest.main()
