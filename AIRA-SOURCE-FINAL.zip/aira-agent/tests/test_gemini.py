import tempfile
import unittest
from pathlib import Path

from ai.gemini_client import (AuthError, BadRequest, GeminiClient, GeminiError, NoApiKey, RetriesExhausted)
from ai.response_parser import ResponseError, extract_text, parse_tool_call
from tests.helpers import FAKE_KEY, FakeTransport, make_settings, ok_body

MSG = [{"role": "user", "text": "hi"}]


class GeminiTests(unittest.TestCase):
    def setUp(self):
        self.s = make_settings(Path(tempfile.mkdtemp()))
        self.sleeps = []

    def client(self, script, key=FAKE_KEY):
        self.t = FakeTransport(script)
        return GeminiClient(self.s, key_provider=lambda: key, transport=self.t,
                            sleep=self.sleeps.append, rng=lambda: 0.5)

    def test_success(self):
        r = self.client([(200, ok_body("hey"))]).generate(MSG, "sys")
        self.assertEqual(r.text, "hey")
        self.assertEqual(len(self.t.calls), 1)

    def test_key_in_header_not_url(self):
        self.client([(200, ok_body())]).generate(MSG)
        call = self.t.calls[0]
        self.assertNotIn(FAKE_KEY, call["url"])
        self.assertEqual(call["headers"]["x-goog-api-key"], FAKE_KEY)

    def test_retry_then_success_with_exponential_backoff(self):
        c = self.client([(429, "x"), (503, "x"), (200, ok_body("ok"))])
        self.assertEqual(c.generate(MSG).text, "ok")
        self.assertEqual(self.sleeps, [0.75, 1.5])  # base 1,2 * jitter 0.75

    def test_each_retryable_status(self):
        for code in (429, 500, 502, 503, 504):
            self.sleeps.clear()
            c = self.client([(code, "x"), (200, ok_body())])
            self.assertEqual(c.generate(MSG).text, "hello", code)
            self.assertEqual(len(self.sleeps), 1)

    def test_timeout_and_network_errors_retried(self):
        c = self.client([TimeoutError(), OSError("down"), (200, ok_body())])
        self.assertEqual(c.generate(MSG).text, "hello")

    def test_auth_errors_not_retried(self):
        for code in (401, 403):
            c = self.client([(code, "denied")] * 5)
            with self.assertRaises(AuthError):
                c.generate(MSG)
            self.assertEqual(len(self.t.calls), 1)
            self.assertEqual(self.sleeps, [])

    def test_invalid_key_400_is_auth_error(self):
        with self.assertRaises(AuthError):
            self.client([(400, '{"error":{"message":"API key not valid"}}')]).generate(MSG)

    def test_other_400_not_retried(self):
        with self.assertRaises(BadRequest):
            self.client([(400, "bad")] * 3).generate(MSG)
        self.assertEqual(len(self.t.calls), 1)

    def test_fallback_model_used_after_exhaustion(self):
        script = [(503, "x")] * 3 + [(200, ok_body("fb"))]
        r = self.client(script).generate(MSG)
        self.assertEqual(r.model, self.s["fallback_models"][0])
        self.assertIn(self.s["fallback_models"][0], self.t.calls[-1]["url"])

    def test_404_moves_to_fallback_immediately(self):
        r = self.client([(404, "nf"), (200, ok_body("fb"))]).generate(MSG)
        self.assertEqual(r.model, self.s["fallback_models"][0])
        self.assertEqual(self.sleeps, [])

    def test_all_fail_raises_exhausted_without_secret(self):
        with self.assertRaises(RetriesExhausted) as cm:
            self.client([(503, "x")] * 20).generate(MSG)
        self.assertNotIn(FAKE_KEY, str(cm.exception))
        self.assertEqual(len(self.t.calls), 6)  # 3 attempts x 2 models

    def test_missing_key_makes_no_request(self):
        c = self.client([], key=None)
        with self.assertRaises(NoApiKey):
            c.generate(MSG)
        self.assertEqual(self.t.calls, [])

    def test_empty_and_blocked_responses_are_errors(self):
        with self.assertRaises(GeminiError):
            self.client([(200, '{"candidates":[{"content":{"parts":[{"text":"  "}]}}]}')]).generate(MSG)
        with self.assertRaises(GeminiError):
            self.client([(200, '{"promptFeedback":{"blockReason":"SAFETY"}}')]).generate(MSG)

    def test_diagnose_never_raises(self):
        d = self.client([(401, "no")]).diagnose()
        self.assertFalse(d["ok"])
        self.assertEqual(d["kind"], "auth")
        d = self.client([(200, ok_body("ok"))]).diagnose()
        self.assertTrue(d["ok"])
        d = self.client([], key=None).diagnose()
        self.assertEqual(d["kind"], "no_key")

    def test_diagnose_single_attempt(self):
        d = self.client([(503, "x")] * 5).diagnose()
        self.assertFalse(d["ok"])
        self.assertEqual(len(self.t.calls), 1)

    def test_request_body_roles(self):
        import json
        c = self.client([(200, ok_body())])
        c.generate([{"role": "user", "text": "a"}, {"role": "assistant", "text": "b"}], "S")
        body = json.loads(self.t.calls[0]["body"])
        self.assertEqual([x["role"] for x in body["contents"]], ["user", "model"])
        self.assertEqual(body["systemInstruction"]["parts"][0]["text"], "S")


class ParserTests(unittest.TestCase):
    def test_tool_call_parsed(self):
        call, plain, err = parse_tool_call('Sure\n```aira-tool\n{"name":"read_file","args":{"path":"a.txt"}}\n```')
        self.assertEqual(call.name, "read_file")
        self.assertEqual(plain, "Sure")
        self.assertIsNone(err)

    def test_malformed_tool_call(self):
        call, _, err = parse_tool_call("```aira-tool\n{oops\n```")
        self.assertIsNone(call)
        self.assertTrue(err)

    def test_plain_text(self):
        self.assertEqual(parse_tool_call("just text")[0:2], (None, "just text"))

    def test_extract_text_errors(self):
        with self.assertRaises(ResponseError):
            extract_text([])


if __name__ == "__main__":
    unittest.main()
