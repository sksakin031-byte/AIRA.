import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from ai.gemini_client import GeminiResponse
from core import router
from core.config import ConfigError, ROOT, load_settings
from core.main import build_app
from tests.helpers import FakeTransport, make_settings, ok_body
from tools.registry import build_default_registry


class ScriptedClient:
    def __init__(self, texts):
        self.texts = list(texts)
        self.calls = []

    def generate(self, contents, system="", **kw):
        self.calls.append(contents)
        return GeminiResponse(self.texts.pop(0), "fake-model")

    def diagnose(self):
        return {"ok": True, "kind": "ok", "model": "fake-model", "latency": 0.0}


def tool_block(name, args):
    return "```aira-tool\n" + json.dumps({"name": name, "args": args}) + "\n```"


class Session:
    def __init__(self, tmp, inputs, client=None, **over):
        self.out = []
        it = iter(inputs)

        def feed(p=""):
            try:
                return next(it)
            except StopIteration:
                raise EOFError

        self.s = make_settings(tmp, **over)
        self.app = build_app(self.s, input_fn=feed, output_fn=self.out.append, client=client)

    @property
    def text(self):
        return "\n".join(self.out)


class RegistryTests(unittest.TestCase):
    def test_registry_contents(self):
        reg = build_default_registry(make_settings(Path(tempfile.mkdtemp())))
        self.assertEqual(reg.names(), ["list_files", "project_structure", "read_file",
                                       "run_tests", "validate_python", "write_file"])
        flags = {d["name"]: d["needs_approval"] for d in reg.describe()}
        self.assertTrue(flags["write_file"] and flags["run_tests"])
        self.assertFalse(flags["read_file"])
        self.assertNotIn("shell", reg.names())

    def test_run_tests_uses_fixed_argv(self):
        tmp = Path(tempfile.mkdtemp())
        s = make_settings(tmp)
        with mock.patch("tools.safe_tests.subprocess.run") as run:
            run.return_value = mock.Mock(returncode=0, stdout="OK", stderr="")
            s2 = Session(tmp, ["y"])
            res = s2.app.engine.tool("run_tests", {})
        self.assertTrue(res.ok and res.data["passed"])
        argv = run.call_args[0][0]
        self.assertEqual(argv[1:3], ["-m", "unittest"])
        self.assertNotIn("shell", run.call_args[1])

    def test_run_tests_requires_approval(self):
        tmp = Path(tempfile.mkdtemp())
        with mock.patch("tools.safe_tests.subprocess.run") as run:
            res = Session(tmp, ["n"]).app.engine.tool("run_tests", {})
        self.assertTrue(res.denied)
        run.assert_not_called()


class PlannerTests(unittest.TestCase):
    def test_model_write_denied_reports_denial_and_nothing_written(self):
        tmp = Path(tempfile.mkdtemp())
        client = ScriptedClient([tool_block("write_file", {"path": "a.txt", "content": "x"}),
                                 "I wrote the file successfully!"])
        s = Session(tmp, ["n"], client=client)
        out = s.app.engine.ask("make a.txt")
        self.assertFalse((s.s["workspace_path"] / "a.txt").exists())
        self.assertIn("✘ write_file", out.reply)  # AIRA's own status line contradicts the model's claim

    def test_model_write_approved_and_verified(self):
        tmp = Path(tempfile.mkdtemp())
        client = ScriptedClient([tool_block("write_file", {"path": "a.txt", "content": "x"}), "done"])
        s = Session(tmp, ["y"], client=client)
        out = s.app.engine.ask("make a.txt")
        self.assertEqual((s.s["workspace_path"] / "a.txt").read_text(), "x")
        self.assertIn("✔ write_file", out.reply)
        self.assertEqual(s.app.engine.memory.count(), 2)

    def test_tool_result_fed_back_to_model(self):
        tmp = Path(tempfile.mkdtemp())
        client = ScriptedClient([tool_block("list_files", {}), "listed"])
        s = Session(tmp, [], client=client)
        s.app.engine.ask("list")
        self.assertIn("TOOL_RESULT", client.calls[1][-1]["text"])

    def test_tool_step_limit(self):
        tmp = Path(tempfile.mkdtemp())
        client = ScriptedClient([tool_block("list_files", {})] * 10)
        s = Session(tmp, [], client=client, max_tool_steps=2)
        out = s.app.engine.ask("loop")
        self.assertEqual(len(out.events), 2)

    def test_failed_turn_not_persisted(self):
        tmp = Path(tempfile.mkdtemp())
        from ai.gemini_client import RetriesExhausted
        class Boom(ScriptedClient):
            def generate(self, *a, **k):
                raise RetriesExhausted("down")
        s = Session(tmp, ["hello", "/exit"], client=Boom([]))
        s.app.run()
        self.assertEqual(s.app.engine.memory.count(), 0)
        self.assertIn("down", s.text)


class RouterTests(unittest.TestCase):
    def test_parse(self):
        self.assertIsNone(router.parse("   "))
        self.assertEqual(router.parse("hi there"), router.Chat("hi there"))
        self.assertEqual(router.parse("/read a.txt"), router.Command("read", ("a.txt",)))
        self.assertEqual(router.parse("/quit"), router.Command("exit", ()))
        self.assertEqual(router.parse("/বের"), router.Command("exit", ()))
        self.assertEqual(router.parse("/bogus").kind, "unknown")
        self.assertEqual(router.parse("/read").kind, "args")
        self.assertEqual(router.parse("/help extra").kind, "args")
        self.assertEqual(router.parse("/lang fr").kind, "args")
        self.assertEqual(router.parse("x" * 9000).kind, "long")


class CliTests(unittest.TestCase):
    def test_banner_help_status_and_exit(self):
        s = Session(Path(tempfile.mkdtemp()), ["/help", "/status", "/bogus", "/read", "", "/exit"])
        self.assertEqual(s.app.run(), 0)
        self.assertIn("AIRA", s.text)
        self.assertIn("gemini-2.5-flash", s.text)
        self.assertIn("/help", s.text)
        self.assertIn("অজানা কমান্ড", s.text)
        self.assertIn("বিদায়", s.text)

    def test_english_mode(self):
        s = Session(Path(tempfile.mkdtemp()), ["/lang en", "/bogus", "/exit"], language="en")
        s.app.run()
        self.assertIn("Unknown command", s.text)

    def test_eof_exits_gracefully(self):
        s = Session(Path(tempfile.mkdtemp()), [])
        self.assertEqual(s.app.run(), 0)

    def test_keyboard_interrupt_exits_gracefully(self):
        tmp = Path(tempfile.mkdtemp())
        out = []
        def raiser(p=""):
            raise KeyboardInterrupt
        app = build_app(make_settings(tmp), input_fn=raiser, output_fn=out.append, client=ScriptedClient([]))
        self.assertEqual(app.run(), 0)

    def test_write_command_flow_with_approval(self):
        tmp = Path(tempfile.mkdtemp())
        s = Session(tmp, ["/write n.txt", "line1", "line2", ".end", "y", "/read n.txt", "/exit"])
        s.app.run()
        self.assertEqual((s.s["workspace_path"] / "n.txt").read_text(), "line1\nline2\n")
        self.assertIn("verified", s.text)

    def test_write_command_denied(self):
        tmp = Path(tempfile.mkdtemp())
        s = Session(tmp, ["/write n.txt", "data", ".end", "", "/exit"])
        s.app.run()
        self.assertFalse((s.s["workspace_path"] / "n.txt").exists())
        self.assertIn("প্রত্যাখ্যাত", s.text)

    def test_write_cancel(self):
        s = Session(Path(tempfile.mkdtemp()), ["/write n.txt", "data", ".cancel", "/exit"])
        s.app.run()
        self.assertFalse((s.s["workspace_path"] / "n.txt").exists())

    def test_traversal_via_cli_rejected(self):
        s = Session(Path(tempfile.mkdtemp()), ["/read ../../etc/passwd", "/exit"])
        s.app.run()
        self.assertIn("traversal", s.text)

    def test_chat_without_key_shows_hint(self):
        tmp = Path(tempfile.mkdtemp())
        env = {k: v for k, v in os.environ.items() if k != "GEMINI_API_KEY"}
        env["AIRA_KEY_FILE"] = str(tmp / "nokey")
        with mock.patch.dict(os.environ, env, clear=True):
            s = Session(tmp, ["hello", "/exit"], client=None)
            s.app.run()
        self.assertIn("API", s.text)
        self.assertEqual(s.app.engine.memory.count(), 0)

    def test_chat_end_to_end_with_mocked_transport(self):
        tmp = Path(tempfile.mkdtemp())
        out = []
        it = iter(["আপনি কেমন আছেন?", "/exit"])
        t = FakeTransport([(200, ok_body("আমি ভালো আছি"))])
        with mock.patch.dict(os.environ, {"GEMINI_API_KEY": "k" * 20}):
            app = build_app(make_settings(tmp), input_fn=lambda p="": next(it), output_fn=out.append, transport=t)
            app.run()
        self.assertIn("আমি ভালো আছি", "\n".join(out))
        self.assertEqual(app.engine.memory.count(), 2)

    def test_process_startup(self):
        for argv in (["--version"], ["--self-check"]):
            p = subprocess.run([sys.executable, "-m", "core.main"] + argv, cwd=str(ROOT),
                               capture_output=True, text=True, timeout=60,
                               env={**os.environ, "AIRA_IN_TEST_RUN": "1", "PYTHONDONTWRITEBYTECODE": "1"})
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertIn("AIRA", p.stdout)

    def test_process_interactive_exit(self):
        p = subprocess.run([sys.executable, "-m", "core.main"], cwd=str(ROOT), input="/help\n/exit\n",
                           capture_output=True, text=True, timeout=60,
                           env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn("/help", p.stdout)

    def test_bad_config_reports_error(self):
        tmp = Path(tempfile.mkdtemp())
        bad = tmp / "bad.json"
        bad.write_text('{"max_retries": 0}')
        p = subprocess.run([sys.executable, "-m", "core.main", "--config", str(bad), "--version"],
                           cwd=str(ROOT), capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 0)  # --version short-circuits
        p = subprocess.run([sys.executable, "-m", "core.main", "--config", str(bad), "--self-check"],
                           cwd=str(ROOT), capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 2)
        self.assertIn("max_retries", p.stderr)


class CompatTests(unittest.TestCase):
    """Backward compatibility with older data/config shapes."""

    def test_legacy_list_memory_loads(self):
        from memory.store import MemoryStore
        tmp = Path(tempfile.mkdtemp())
        p = tmp / "memory.json"
        p.write_text(json.dumps([{"role": "user", "content": "পুরনো"}, {"role": "assistant", "text": "ok"},
                                 {"role": "weird", "text": "dropped"}]), encoding="utf-8")
        r = MemoryStore(p, 1 << 20).load()
        self.assertTrue(r.migrated)
        self.assertEqual([m.text for m in r.messages], ["পুরনো", "ok"])
        self.assertTrue(p.exists())  # untouched until next save

    def test_partial_old_config_gets_defaults(self):
        tmp = Path(tempfile.mkdtemp())
        cfg = tmp / "s.json"
        cfg.write_text('{"model": "gemini-2.0-flash", "some_removed_key": 1}')
        s = load_settings(str(cfg))
        self.assertEqual(s["model"], "gemini-2.0-flash")
        self.assertEqual(s["history_limit"], 20)

    def test_invalid_settings_rejected(self):
        for bad in ({"language": "fr"}, {"model": "a b"}, {"timeout_seconds": -1},
                    {"workspace_dir": "../x"}, {"api_base": "http://x"}, {"max_retries": True}):
            with self.assertRaises(ConfigError, msg=str(bad)):
                load_settings(overrides=bad)


if __name__ == "__main__":
    unittest.main()
