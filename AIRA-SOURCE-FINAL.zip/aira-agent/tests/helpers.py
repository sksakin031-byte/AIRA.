import json
import tempfile
from pathlib import Path

from core.config import load_settings, ROOT


def make_settings(tmp: Path, **over):
    o = {"workspace_dir": str(tmp / "ws"), "data_dir": str(tmp / "data"),
         "backoff_base_seconds": 1.0, "max_retries": 3}
    o.update(over)
    return load_settings(root=ROOT, overrides=o)


FAKE_KEY = "AIza" + "Sy" + "X" * 33  # built at runtime so no key-like literal exists in source


def ok_body(text="hello"):
    return json.dumps({"candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}]})


class FakeTransport:
    """Scripted transport: items are (status, body) tuples or exception instances."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body, "timeout": timeout})
        item = self.script.pop(0) if self.script else (200, ok_body())
        if isinstance(item, BaseException):
            raise item
        return item
