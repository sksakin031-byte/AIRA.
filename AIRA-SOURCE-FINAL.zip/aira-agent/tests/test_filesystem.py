import os
import tempfile
import unittest
from pathlib import Path

from tools.filesystem import FileOps
from tools.validators import ValidationError, resolve_in_workspace

EXT = [".txt", ".md", ".py", ".json"]


class FileTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.ws = self.tmp / "ws"
        self.ops = FileOps(self.ws, 1000, EXT)

    def test_write_read_roundtrip_verified(self):
        r = self.ops.write_file("a/b.txt", "বাংলা text\n")
        self.assertTrue(r["verified"])
        self.assertEqual(self.ops.read_file("a/b.txt")["content"], "বাংলা text\n")

    def test_no_accidental_overwrite(self):
        self.ops.write_file("a.txt", "one")
        with self.assertRaises(ValidationError):
            self.ops.write_file("a.txt", "two")
        self.assertEqual(self.ops.read_file("a.txt")["content"], "one")

    def test_overwrite_makes_backup(self):
        self.ops.write_file("a.txt", "one")
        r = self.ops.write_file("a.txt", "two", overwrite=True)
        self.assertEqual(self.ops.read_file("a.txt")["content"], "two")
        self.assertEqual((self.ws / r["backup"]).read_text(), "one")

    def test_overwrite_nonexistent_rejected(self):
        with self.assertRaises(ValidationError):
            self.ops.write_file("none.txt", "x", overwrite=True)

    def test_path_traversal_rejected(self):
        for bad in ["../x.txt", "a/../../x.txt", "/etc/passwd", "~/x.txt", "C:/x.txt", "..\\x.txt", "a\x00b.txt", ""]:
            with self.assertRaises(ValidationError, msg=bad):
                self.ops.write_file(bad, "x")
        self.assertFalse((self.tmp / "x.txt").exists())

    @unittest.skipUnless(hasattr(os, "symlink"), "symlinks unsupported")
    def test_symlink_file_escape_rejected(self):
        outside = self.tmp / "outside.txt"
        outside.write_text("secret")
        os.symlink(outside, self.ws / "link.txt")
        with self.assertRaises(ValidationError):
            self.ops.read_file("link.txt")
        with self.assertRaises(ValidationError):
            self.ops.write_file("link.txt", "x", overwrite=True)
        self.assertEqual(outside.read_text(), "secret")

    @unittest.skipUnless(hasattr(os, "symlink"), "symlinks unsupported")
    def test_symlink_dir_escape_rejected(self):
        outdir = self.tmp / "outdir"
        outdir.mkdir()
        os.symlink(outdir, self.ws / "d")
        with self.assertRaises(ValidationError):
            self.ops.write_file("d/new.txt", "x")
        with self.assertRaises(ValidationError):
            self.ops.list_files("d")
        self.assertEqual(list(outdir.iterdir()), [])

    def test_size_limit(self):
        with self.assertRaises(ValidationError):
            self.ops.write_file("big.txt", "x" * 1001)
        (self.ws / "big2.txt").write_text("x" * 2000)
        with self.assertRaises(ValidationError):
            self.ops.read_file("big2.txt")

    def test_unsafe_types_rejected(self):
        for name in ["run.sh", "a.exe", "noext", ".bashrc", "lib.so"]:
            with self.assertRaises(ValidationError, msg=name):
                self.ops.write_file(name, "x")

    def test_binary_content_rejected(self):
        with self.assertRaises(ValidationError):
            self.ops.write_file("a.txt", "a\x00b")
        (self.ws / "bin.txt").write_bytes(b"\xff\xfe\x00")
        with self.assertRaises(ValidationError):
            self.ops.read_file("bin.txt")

    def test_validate_python(self):
        self.ops.write_file("ok.py", "x = 1\n")
        self.ops.write_file("bad.py", "def (:\n")
        self.assertTrue(self.ops.validate_python("ok.py")["valid"])
        r = self.ops.validate_python("bad.py")
        self.assertFalse(r["valid"])
        self.assertEqual(r["line"], 1)
        self.ops.write_file("n.txt", "x")
        with self.assertRaises(ValidationError):
            self.ops.validate_python("n.txt")

    def test_validate_python_does_not_execute(self):
        marker = self.tmp / "ran"
        self.ops.write_file("evil.py", f"open({str(marker)!r}, 'w').write('x')\n")
        self.assertTrue(self.ops.validate_python("evil.py")["valid"])
        self.assertFalse(marker.exists())

    def test_list_and_structure(self):
        self.ops.write_file("d/a.txt", "1")
        names = [e["name"] for e in self.ops.list_files(".")["entries"]]
        self.assertIn("d", names)
        self.assertIn("a.txt", self.ops.project_structure()["tree"])

    def test_resolve_must_exist(self):
        with self.assertRaises(ValidationError):
            resolve_in_workspace(self.ws, "missing.txt", must_exist=True)


if __name__ == "__main__":
    unittest.main()
