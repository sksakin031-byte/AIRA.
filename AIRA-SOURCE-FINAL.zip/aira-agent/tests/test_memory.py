import json
import tempfile
import unittest
from pathlib import Path

from memory.manager import MemoryManager
from memory.store import MemoryStore


class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.path = self.tmp / "memory.json"

    def mgr(self, limit=20, max_bytes=1 << 20):
        return MemoryManager(MemoryStore(self.path, max_bytes), limit)

    def test_persistence(self):
        m = self.mgr()
        m.add("user", "হ্যালো")
        m.add("assistant", "hi")
        m2 = self.mgr()
        self.assertEqual(m2.count(), 2)
        self.assertEqual(m2.context()[0]["text"], "হ্যালো")

    def test_history_limit_and_user_first(self):
        m = self.mgr(limit=3)
        for i in range(4):
            m.add("user", f"u{i}")
            m.add("assistant", f"a{i}")
        ctx = m.context()
        self.assertLessEqual(len(ctx), 3)
        self.assertEqual(ctx[0]["role"], "user")

    def test_corruption_recovery_preserves_original(self):
        m = self.mgr()
        m.add("user", "one")
        m.add("assistant", "two")  # second save creates a valid .bak
        self.path.write_text("{not json", encoding="utf-8")
        m2 = self.mgr()
        self.assertTrue(m2.recovered)
        self.assertEqual(m2.count(), 1)  # restored from backup (state before last save)
        quarantined = list(self.tmp.glob("memory.json.corrupt-*"))
        self.assertEqual(len(quarantined), 1)
        self.assertEqual(quarantined[0].read_text(encoding="utf-8"), "{not json")

    def test_corruption_without_backup_starts_empty_but_keeps_file(self):
        self.path.write_text("garbage", encoding="utf-8")
        m = self.mgr()
        self.assertEqual(m.count(), 0)
        self.assertEqual(len(list(self.tmp.glob("memory.json.corrupt-*"))), 1)

    def test_checksum_tamper_detected(self):
        m = self.mgr()
        m.add("user", "secret plan")
        doc = json.loads(self.path.read_text(encoding="utf-8"))
        doc["messages"][0]["text"] = "tampered"
        self.path.write_text(json.dumps(doc), encoding="utf-8")
        self.assertTrue(self.mgr().recovered)

    def test_max_storage_limit(self):
        m = self.mgr(max_bytes=65536)
        for i in range(200):
            m.add("user", "x" * 1000)
        self.assertLessEqual(self.path.stat().st_size, 65536)
        self.assertGreater(self.mgr().count(), 0)

    def test_atomic_write_leaves_no_temp_files(self):
        m = self.mgr()
        m.add("user", "a")
        self.assertEqual([p.name for p in self.tmp.glob(".mem-*")], [])

    def test_invalid_role_rejected(self):
        with self.assertRaises(ValueError):
            self.mgr().add("system", "x")


if __name__ == "__main__":
    unittest.main()
