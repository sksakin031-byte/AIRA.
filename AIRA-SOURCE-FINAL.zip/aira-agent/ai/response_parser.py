"""Parse Gemini responses and model-issued tool requests."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass


class ResponseError(Exception):
    pass


@dataclass
class ToolCall:
    name: str
    args: dict


def extract_text(payload) -> str:
    if not isinstance(payload, dict):
        raise ResponseError("unexpected response shape")
    cands = payload.get("candidates")
    if not cands:
        reason = (payload.get("promptFeedback") or {}).get("blockReason")
        raise ResponseError(f"no candidates returned" + (f" (blocked: {reason})" if reason else ""))
    cand = cands[0] if isinstance(cands[0], dict) else {}
    parts = (cand.get("content") or {}).get("parts") or []
    text = "".join(p.get("text", "") for p in parts if isinstance(p, dict))
    if not text.strip():
        raise ResponseError(f"empty response (finishReason={cand.get('finishReason')})")
    return text


_TOOL_RE = re.compile(r"```aira-tool\s*(.*?)```", re.S)


def parse_tool_call(text: str):
    """Return (ToolCall | None, plain_text, error | None). Only the first request is honoured."""
    m = _TOOL_RE.search(text)
    if not m:
        return None, text.strip(), None
    plain = (text[:m.start()] + text[m.end():]).strip()
    try:
        obj = json.loads(m.group(1))
    except ValueError:
        return None, plain, "malformed tool request"
    if not isinstance(obj, dict) or not isinstance(obj.get("name"), str):
        return None, plain, "malformed tool request"
    args = obj.get("args", {})
    if not isinstance(args, dict):
        return None, plain, "malformed tool request"
    return ToolCall(obj["name"], args), plain, None
