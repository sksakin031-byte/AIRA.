"""Reliable Gemini REST client (stdlib only)."""
from __future__ import annotations

import json
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass

from ai.response_parser import ResponseError, extract_text
from security.secrets import get_api_key, redact

RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class GeminiError(Exception):
    kind = "error"


class NoApiKey(GeminiError):
    kind = "no_key"


class AuthError(GeminiError):
    kind = "auth"


class BadRequest(GeminiError):
    kind = "bad_request"


class RetriesExhausted(GeminiError):
    kind = "exhausted"


@dataclass
class GeminiResponse:
    text: str
    model: str
    attempts: int = 1


def urllib_transport(url, headers, body, timeout):
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")


class _Retry(Exception):
    def __init__(self, why):
        self.why = why


class _NextModel(Exception):
    def __init__(self, why):
        self.why = why


class GeminiClient:
    def __init__(self, settings, key_provider=get_api_key, transport=urllib_transport,
                 sleep=time.sleep, rng=random.random):
        self.s = settings
        self._key = key_provider
        self._transport = transport
        self._sleep = sleep
        self._rng = rng

    def models(self) -> list:
        out = [self.s["model"]]
        out += [m for m in self.s["fallback_models"] if m not in out]
        return out

    def backoff_delay(self, attempt: int) -> float:
        base = min(self.s["backoff_max_seconds"], self.s["backoff_base_seconds"] * (2 ** attempt))
        return base * (0.5 + 0.5 * self._rng())  # jitter in [50%, 100%]

    def _body(self, contents, system) -> bytes:
        payload = {"contents": [
            {"role": "model" if c["role"] == "assistant" else "user", "parts": [{"text": c["text"]}]}
            for c in contents]}
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        return json.dumps(payload).encode("utf-8")

    def _once(self, model, body, key):
        url = f"{self.s['api_base']}/models/{model}:generateContent"
        headers = {"Content-Type": "application/json", "x-goog-api-key": key}
        try:
            status, text = self._transport(url, headers, body, self.s["timeout_seconds"])
        except (TimeoutError, OSError) as exc:
            raise _Retry(f"network error: {type(exc).__name__}")
        if status == 200:
            try:
                return extract_text(json.loads(text))
            except ValueError:
                raise _Retry("invalid JSON in response")
        snippet = redact(text)[:200]
        if status in RETRYABLE_STATUS:
            raise _Retry(f"HTTP {status}")
        if status in (401, 403):
            raise AuthError(f"HTTP {status}: authentication/permission failure; check your API key")
        if status == 404:
            raise _NextModel(f"model '{model}' not available (HTTP 404)")
        if status == 400:
            if "API key" in text or "API_KEY" in text:
                raise AuthError("HTTP 400: API key rejected")
            raise BadRequest(f"HTTP 400: {snippet}")
        raise GeminiError(f"unexpected HTTP {status}: {snippet}")

    def generate(self, contents, system="", *, single_attempt=False) -> GeminiResponse:
        key = self._key()
        if not key:
            raise NoApiKey("no API key configured")
        body = self._body(contents, system)
        models = [self.s["model"]] if single_attempt else self.models()
        attempts_allowed = 1 if single_attempt else self.s["max_retries"]
        log = []
        total = 0
        for model in models:
            for attempt in range(attempts_allowed):
                total += 1
                try:
                    text = self._once(model, body, key)
                    return GeminiResponse(text, model, total)
                except _Retry as r:
                    log.append(f"{model}: {r.why}")
                    if attempt + 1 < attempts_allowed:
                        self._sleep(self.backoff_delay(attempt))
                except _NextModel as n:
                    log.append(f"{model}: {n.why}")
                    break
                except ResponseError as exc:
                    raise GeminiError(f"{model}: {exc}") from exc
        raise RetriesExhausted("all models failed: " + "; ".join(log[-6:]))

    def diagnose(self) -> dict:
        """One lightweight request to the primary model; never raises."""
        start = time.time()
        try:
            r = self.generate([{"role": "user", "text": "ping"}], "Reply with: ok", single_attempt=True)
            return {"ok": True, "kind": "ok", "model": r.model, "latency": round(time.time() - start, 2)}
        except GeminiError as exc:
            return {"ok": False, "kind": exc.kind, "detail": redact(str(exc)),
                    "latency": round(time.time() - start, 2)}
