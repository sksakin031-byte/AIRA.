#!/usr/bin/env bash
# Offline test suite - needs no API key and no network.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
[ -n "$PY" ] || { echo "Python not found." >&2; exit 1; }
unset GEMINI_API_KEY
export PYTHONDONTWRITEBYTECODE=1
exec "$PY" -m unittest discover -s tests -t . -v
