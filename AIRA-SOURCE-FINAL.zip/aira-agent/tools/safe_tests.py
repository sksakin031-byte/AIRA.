"""Run the project's own predefined test suite. No caller-supplied arguments."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from security.secrets import ENV_VAR, redact

_ARGV = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-t", "."]


def run_project_tests(project_root: Path, timeout: int = 180) -> dict:
    env = {k: v for k, v in os.environ.items() if k != ENV_VAR}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["AIRA_IN_TEST_RUN"] = "1"
    try:
        proc = subprocess.run(_ARGV, cwd=str(project_root), capture_output=True, text=True,
                              timeout=timeout, env=env, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        return {"passed": False, "returncode": None, "output": "timed out"}
    out = redact((proc.stdout or "") + (proc.stderr or ""))
    return {"passed": proc.returncode == 0, "returncode": proc.returncode, "output": out[-3000:]}
