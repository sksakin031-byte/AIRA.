"""Input and path validation. Everything file-related funnels through here."""
from __future__ import annotations

import re
from pathlib import Path, PurePosixPath


class ValidationError(Exception):
    pass


def resolve_in_workspace(workspace: Path, rel, *, must_exist: bool = False) -> Path:
    """Map a user/AI supplied relative path to a path inside the workspace.

    Rejects absolute paths, '..', NUL bytes, drive letters and any symlink component.
    """
    if not isinstance(rel, str) or not rel.strip():
        raise ValidationError("path must be a non-empty string")
    if "\x00" in rel or len(rel) > 255:
        raise ValidationError("invalid path")
    norm = rel.replace("\\", "/")
    if norm.startswith("/") or norm.startswith("~") or re.match(r"^[A-Za-z]:", norm):
        raise ValidationError("absolute paths are not allowed")
    parts = PurePosixPath(norm).parts
    if ".." in parts:
        raise ValidationError("path traversal is not allowed")
    root = Path(workspace).resolve()
    cur = root
    for part in parts:
        if part in (".", ""):
            continue
        cur = cur / part
        if cur.is_symlink():
            raise ValidationError("symlinks are not allowed")
    real = cur.resolve()
    if real != root and root not in real.parents:
        raise ValidationError("path escapes the workspace")
    if must_exist and not cur.exists():
        raise ValidationError("path does not exist")
    return cur


def check_extension(path: Path, allowed) -> None:
    if path.suffix.lower() not in set(allowed):
        raise ValidationError(f"file type not allowed: {path.suffix or '(none)'}")


def check_text(content, max_bytes: int) -> bytes:
    if not isinstance(content, str):
        raise ValidationError("content must be text")
    if "\x00" in content:
        raise ValidationError("binary content is not allowed")
    data = content.encode("utf-8")
    if len(data) > max_bytes:
        raise ValidationError(f"content exceeds {max_bytes} bytes")
    return data
