"""Tool registry. Sensitivity is decided by security.permissions, not by tools."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Callable

from security import permissions
from tools.filesystem import FileOps
from tools.safe_tests import run_project_tests


@dataclass
class Tool:
    name: str
    description: str
    params: dict  # name -> (type_name, required)
    handler: Callable
    describe: Callable = None  # args -> (target, details)


class Registry:
    def __init__(self):
        self._tools: dict = {}

    def register(self, tool: Tool) -> None:
        if permissions.classify(tool.name) == "unknown":
            raise ValueError(f"tool {tool.name!r} has no permission classification")
        if tool.name in self._tools:
            raise ValueError(f"duplicate tool {tool.name!r}")
        self._tools[tool.name] = tool

    def get(self, name):
        return self._tools.get(name) if isinstance(name, str) else None

    def names(self) -> list:
        return sorted(self._tools)

    def describe(self) -> list:
        out = []
        for n in self.names():
            t = self._tools[n]
            args = ", ".join(f"{k}{'' if req else '?'}:{typ}" for k, (typ, req) in t.params.items())
            out.append({"name": n, "args": args, "description": t.description,
                        "needs_approval": permissions.classify(n) == "sensitive"})
        return out


def build_default_registry(settings: dict) -> Registry:
    ops = FileOps(settings["workspace_path"], settings["max_file_bytes"], settings["allowed_extensions"])
    root = settings["project_root"]
    reg = Registry()

    def write_describe(a):
        content = a.get("content", "") if isinstance(a.get("content"), str) else ""
        raw = content.encode("utf-8", "replace")
        preview = content[:120].replace("\n", "\\n")
        return a.get("path", "?"), (f"bytes={len(raw)} sha256={hashlib.sha256(raw).hexdigest()[:12]} "
                                    f"overwrite={'yes' if a.get('overwrite') else 'no'} preview='{preview}'")

    reg.register(Tool("list_files", "List files in a workspace directory", {"path": ("str", False)},
                      lambda a: ops.list_files(a.get("path", "."))))
    reg.register(Tool("read_file", "Read a text file from the workspace", {"path": ("str", True)},
                      lambda a: ops.read_file(a["path"])))
    reg.register(Tool("write_file", "Write a text file in the workspace (requires human approval)",
                      {"path": ("str", True), "content": ("str", True), "overwrite": ("bool", False)},
                      lambda a: ops.write_file(a["path"], a["content"], bool(a.get("overwrite", False))),
                      write_describe))
    reg.register(Tool("validate_python", "Check a workspace .py file for syntax errors (does not run it)",
                      {"path": ("str", True)}, lambda a: ops.validate_python(a["path"])))
    reg.register(Tool("project_structure", "Show the workspace directory tree", {},
                      lambda a: ops.project_structure()))
    reg.register(Tool("run_tests", "Run AIRA's predefined offline test suite (requires human approval)", {},
                      lambda a: run_project_tests(root),
                      lambda a: ("tests/ (predefined unittest suite)", "no arguments; API key removed from environment")))
    return reg
