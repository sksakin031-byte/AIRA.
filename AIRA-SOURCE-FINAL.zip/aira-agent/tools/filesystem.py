"""Workspace-confined file operations."""
from __future__ import annotations

import hashlib
import os
import shutil
import stat
import tempfile
from pathlib import Path

from tools.validators import ValidationError, check_extension, check_text, resolve_in_workspace

MAX_LIST = 500
MAX_TREE = 400
MAX_DEPTH = 4


class FileOps:
    def __init__(self, workspace, max_file_bytes: int, allowed_extensions):
        self.workspace = Path(workspace)
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.root = self.workspace.resolve()
        self.max_bytes = max_file_bytes
        self.allowed = list(allowed_extensions)

    def _rel(self, p: Path) -> str:
        return p.relative_to(self.root).as_posix() or "."

    def list_files(self, path: str = ".") -> dict:
        d = resolve_in_workspace(self.root, path, must_exist=True)
        if not d.is_dir():
            raise ValidationError("not a directory")
        entries, truncated = [], False
        for name in sorted(os.listdir(d)):
            if len(entries) >= MAX_LIST:
                truncated = True
                break
            p = d / name
            if p.is_symlink():
                entries.append({"name": name, "type": "symlink"})
            elif p.is_dir():
                entries.append({"name": name, "type": "dir"})
            else:
                entries.append({"name": name, "type": "file", "bytes": p.stat().st_size})
        return {"path": self._rel(d), "entries": entries, "truncated": truncated}

    def read_file(self, path: str) -> dict:
        p = resolve_in_workspace(self.root, path, must_exist=True)
        check_extension(p, self.allowed)
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
        try:
            fd = os.open(p, flags)
        except OSError as exc:
            raise ValidationError(f"cannot open file: {exc.strerror}") from exc
        with os.fdopen(fd, "rb") as f:
            st = os.fstat(f.fileno())
            if not stat.S_ISREG(st.st_mode):
                raise ValidationError("not a regular file")
            if st.st_size > self.max_bytes:
                raise ValidationError(f"file exceeds {self.max_bytes} bytes")
            data = f.read(self.max_bytes + 1)
        if len(data) > self.max_bytes:
            raise ValidationError(f"file exceeds {self.max_bytes} bytes")
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValidationError("file is not valid UTF-8 text") from exc
        if "\x00" in text:
            raise ValidationError("binary content is not allowed")
        return {"path": self._rel(p), "content": text, "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest()}

    def write_file(self, path: str, content: str, overwrite: bool = False) -> dict:
        target = resolve_in_workspace(self.root, path)
        check_extension(target, self.allowed)
        data = check_text(content, self.max_bytes)
        if target.exists() and not target.is_file():
            raise ValidationError("target exists and is not a regular file")
        if target.exists() and not overwrite:
            raise ValidationError("file already exists (overwrite not requested)")
        if overwrite and not target.exists():
            raise ValidationError("overwrite requested but file does not exist")
        # create parents one at a time (no symlink following; already validated)
        parent = target.parent
        if not parent.exists():
            missing = []
            cur = parent
            while not cur.exists() and cur != self.root:
                missing.append(cur)
                cur = cur.parent
            for d in reversed(missing):
                os.mkdir(d)
        resolve_in_workspace(self.root, self._rel(target))  # re-validate after mkdir
        backup = None
        if overwrite:
            backup = target.with_name(target.name + ".aira-bak")
            if backup.is_symlink():
                raise ValidationError("backup path is a symlink")
            shutil.copyfile(target, backup)
        fd, tmp = tempfile.mkstemp(dir=target.parent, prefix=".aira-tmp-")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            if overwrite:
                os.replace(tmp, target)
            else:
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
                flags |= getattr(os, "O_CLOEXEC", 0)

                try:
                    out_fd = os.open(target, flags, 0o600)
                except FileExistsError:
                    raise ValidationError(
                        "file already exists (overwrite not requested)"
                    )

                try:
                    with os.fdopen(out_fd, "wb") as out:
                        out.write(data)
                        out.flush()
                        os.fsync(out.fileno())
                except BaseException:
                    try:
                        os.unlink(target)
                    except OSError:
                        pass
                    raise

                os.unlink(tmp)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        expected = hashlib.sha256(data).hexdigest()
        check = self.read_file(self._rel(target))
        verified = check["sha256"] == expected
        return {"path": self._rel(target), "bytes": len(data), "sha256": expected,
                "verified": verified, "overwritten": bool(overwrite),
                "backup": self._rel(backup) if backup else None}

    def validate_python(self, path: str) -> dict:
        p = resolve_in_workspace(self.root, path, must_exist=True)
        if p.suffix.lower() != ".py":
            raise ValidationError("only .py files can be validated")
        src = self.read_file(self._rel(p))["content"]
        try:
            compile(src, p.name, "exec", dont_inherit=True)  # compile only, never executes
        except SyntaxError as exc:
            return {"path": self._rel(p), "valid": False, "line": exc.lineno, "error": exc.msg}
        return {"path": self._rel(p), "valid": True}

    def project_structure(self) -> dict:
        lines, count = [], 0

        def walk(d: Path, depth: int):
            nonlocal count
            for name in sorted(os.listdir(d)):
                if count >= MAX_TREE:
                    return
                p = d / name
                count += 1
                if p.is_symlink():
                    lines.append("  " * depth + name + "@ (symlink)")
                elif p.is_dir():
                    lines.append("  " * depth + name + "/")
                    if depth + 1 < MAX_DEPTH:
                        walk(p, depth + 1)
                else:
                    lines.append("  " * depth + name)

        walk(self.root, 0)
        return {"tree": "\n".join(lines) or "(empty)", "entries": count, "truncated": count >= MAX_TREE}
