"""Tool executor: validation -> permission -> human approval -> execution -> verification."""
from __future__ import annotations

from dataclasses import dataclass, field

from security import permissions
from security.approval import ApprovalRequest
from security.audit import AuditError
from tools.registry import Registry
from tools.validators import ValidationError

_TYPES = {"str": str, "bool": bool}


@dataclass
class ToolResult:
    tool: str
    ok: bool
    data: dict = field(default_factory=dict)
    error: str = ""
    verified: bool = False
    denied: bool = False

    def to_public(self) -> dict:
        def trim(v):
            if isinstance(v, str):
                return v[:4000]
            if isinstance(v, dict):
                return {k: trim(x) for k, x in v.items()}
            if isinstance(v, list):
                return [trim(x) for x in v[:200]]
            return v
        return {"tool": self.tool, "ok": self.ok, "verified": self.verified,
                "denied": self.denied, "error": self.error, "data": trim(self.data)}


class Executor:
    def __init__(self, registry: Registry, approver, audit):
        self.registry = registry
        self.approver = approver
        self.audit = audit

    def _fail(self, name, error, denied=False):
        return ToolResult(name if isinstance(name, str) else "?", False, error=error, denied=denied)

    def execute(self, name, args=None) -> ToolResult:
        args = {} if args is None else args
        try:
            tool = self.registry.get(name)
            if tool is None:
                self.audit.log("tool_rejected", tool=str(name), reason="unknown tool")
                return self._fail(name, "unknown tool")
            err = self._check_args(tool, args)
            if err:
                self.audit.log("tool_rejected", tool=name, reason=err)
                return self._fail(name, err)
            level = permissions.classify(name)
            if level == "unknown":
                self.audit.log("tool_rejected", tool=name, reason="unclassified")
                return self._fail(name, "operation not permitted", denied=True)
            if level == "sensitive":
                target, details = (tool.describe(args) if tool.describe else (str(args.get("path", "-")), ""))
                req = ApprovalRequest.new(name, target, details)
                self.audit.log("approval_requested", tool=name, target=target, request_id=req.request_id)
                approved = self.approver.request(req) is True
                self.audit.log("approval_decision", tool=name, target=target,
                               request_id=req.request_id, approved=approved)
                if not approved:
                    return self._fail(name, "denied by user", denied=True)
            try:
                data = tool.handler(args)
            except (ValidationError, OSError) as exc:
                self.audit.log("tool_failed", tool=name, error=str(exc))
                return self._fail(name, str(exc))
            except Exception as exc:
                # Keep unexpected tool errors from crashing the agent.
                self.audit.log(
                    "tool_failed",
                    tool=name,
                    error="unexpected " + type(exc).__name__
                )
                return self._fail(
                    name,
                    "tool execution failed: " + type(exc).__name__
                )
            verified = bool(data.get("verified", False)) if isinstance(data, dict) else False
            ok = True
            error = ""
            if isinstance(data, dict) and "verified" in data and not data["verified"]:
                ok, error = False, "post-write verification failed"
            self.audit.log("tool_ok" if ok else "tool_failed", tool=name, verified=verified, error=error)
            return ToolResult(name, ok, data if isinstance(data, dict) else {"result": data}, error, verified)
        except AuditError as exc:
            return self._fail(name, f"refused: {exc}", denied=True)  # fail closed

    @staticmethod
    def _check_args(tool, args) -> str:
        if not isinstance(args, dict):
            return "arguments must be an object"
        unknown = set(args) - set(tool.params)
        if unknown:
            return f"unexpected arguments: {', '.join(sorted(map(str, unknown)))}"
        for pname, (ptype, required) in tool.params.items():
            if pname not in args:
                if required:
                    return f"missing argument: {pname}"
                continue
            if not isinstance(args[pname], _TYPES[ptype]):
                return f"argument {pname} must be {ptype}"
        return ""
