"""Durable, atomic, integrity-checked memory file."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from memory.models import Message, MemoryValidationError

FORMAT = "aira-memory"
VERSION = 1
MAX_MESSAGES = 2000


@dataclass
class LoadResult:
    messages: list
    recovered: bool = False
    migrated: bool = False
    note: str = ""
    quarantined: str = ""


def _canon(messages: list) -> str:
    return json.dumps(messages, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _checksum(messages: list) -> str:
    return hashlib.sha256(_canon(messages).encode("utf-8")).hexdigest()


class MemoryStore:
    def __init__(self, path, max_bytes: int):
        self.path = Path(path)
        self.max_bytes = max_bytes

    @property
    def backup_path(self) -> Path:
        return self.path.with_name(self.path.name + ".bak")

    # ---------- reading ----------
    def _parse(self, path: Path):
        """Return (messages, migrated). Raises ValueError if invalid."""
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if isinstance(data, list):  # legacy plain list
            msgs = []
            for item in data:
                try:
                    msgs.append(Message.from_dict(item))
                except MemoryValidationError:
                    continue
            return msgs, True
        if not isinstance(data, dict) or data.get("format") != FORMAT:
            raise ValueError("unrecognised memory format")
        if data.get("version") != VERSION:
            raise ValueError("unsupported memory version")
        items = data.get("messages")
        if not isinstance(items, list):
            raise ValueError("messages missing")
        if data.get("checksum") != _checksum(items):
            raise ValueError("checksum mismatch")
        try:
            return [Message.from_dict(i) for i in items], False
        except MemoryValidationError as exc:
            raise ValueError(str(exc)) from exc

    def load(self) -> LoadResult:
        if not self.path.exists():
            if self.backup_path.exists():
                try:
                    msgs, _ = self._parse(self.backup_path)
                    return LoadResult(msgs, recovered=True, note="main file missing; restored from backup")
                except (OSError, ValueError):
                    pass
            return LoadResult([])
        try:
            msgs, migrated = self._parse(self.path)
            return LoadResult(msgs, migrated=migrated, note="legacy format migrated on next save" if migrated else "")
        except (OSError, ValueError) as exc:
            quarantine = self.path.with_name(f"{self.path.name}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}-{os.getpid()}")
            try:
                os.replace(self.path, quarantine)  # preserve original bytes, never delete
            except OSError:
                quarantine = Path("")
            note = f"memory corrupted ({exc}); original preserved"
            try:
                msgs, _ = self._parse(self.backup_path)
                return LoadResult(msgs, recovered=True, note=note + "; restored from backup", quarantined=str(quarantine))
            except (OSError, ValueError):
                return LoadResult([], recovered=True, note=note + "; started empty", quarantined=str(quarantine))

    # ---------- writing ----------
    def _serialize(self, messages: list) -> bytes:
        items = [m.to_dict() for m in messages][-MAX_MESSAGES:]
        while True:
            doc = {"format": FORMAT, "version": VERSION, "checksum": _checksum(items), "messages": items}
            blob = json.dumps(doc, ensure_ascii=False, indent=1).encode("utf-8")
            if len(blob) <= self.max_bytes or len(items) <= 1:
                return blob
            items = items[1:]  # drop oldest until it fits

    def save(self, messages: list) -> None:
        blob = self._serialize(messages)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            try:
                self._parse(self.path)  # only back up a valid file
                tmp_bak = self.backup_path.with_name(self.backup_path.name + ".tmp")
                shutil.copyfile(self.path, tmp_bak)
                os.replace(tmp_bak, self.backup_path)
            except (OSError, ValueError):
                pass
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".mem-", suffix=".tmp")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(blob)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        try:
            dfd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
        except OSError:
            pass
