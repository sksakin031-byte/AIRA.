"""API key handling and secret redaction."""
from __future__ import annotations

import os
import re
from pathlib import Path

ENV_VAR = "GEMINI_API_KEY"

_PATTERNS = [
    re.compile(r"AIza[0-9A-Za-z_\-]{20,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{10,}"),
    re.compile(r"(?i)((?:api[_-]?key|token|password|secret)[\"']?\s*[:=]\s*[\"']?)[^\s\"',]{6,}"),
]


def default_key_file() -> Path:
    override = os.environ.get("AIRA_KEY_FILE")
    return Path(override) if override else Path.home() / ".aira" / "api_key"


def redact(text) -> str:
    out = str(text)
    out = _PATTERNS[0].sub("[REDACTED]", out)
    out = _PATTERNS[1].sub("Bearer [REDACTED]", out)
    out = _PATTERNS[2].sub(lambda m: m.group(1) + "[REDACTED]", out)
    return out


def get_api_key(key_file=None):
    """Environment variable first, then the key file. Returns None if unset."""
    env = os.environ.get(ENV_VAR, "").strip()
    if env:
        return env
    path = Path(key_file) if key_file else default_key_file()
    try:
        value = path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return value or None


def mask(key: str) -> str:
    return (key[:4] + "…") if key and len(key) > 8 else "…"


def store_api_key(key: str, key_file=None, overwrite: bool = False) -> Path:
    key = key.strip()
    if not key or any(c.isspace() for c in key):
        raise ValueError("invalid key")
    path = Path(key_file) if key_file else default_key_file()
    if path.exists() and not overwrite:
        raise FileExistsError(f"{path} already exists")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key + "\n")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path
