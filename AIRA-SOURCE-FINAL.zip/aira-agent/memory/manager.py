"""High-level memory interface used by the engine."""
from __future__ import annotations

from memory.models import Message
from memory.store import MemoryStore


class MemoryManager:
    def __init__(self, store: MemoryStore, history_limit: int):
        self.store = store
        self.history_limit = history_limit
        result = store.load()
        self._messages: list = list(result.messages)
        self.load_note = result.note
        self.recovered = result.recovered
        self.quarantined = result.quarantined

    def add(self, role: str, text: str) -> None:
        msg = Message(role, text)
        self._messages.append(msg)
        try:
            self.store.save(self._messages)
        except OSError:
            self._messages.pop()
            raise

    def context(self, limit=None) -> list:
        n = limit or self.history_limit
        recent = self._messages[-n:]
        # Gemini expects the conversation to start with a user turn
        while recent and recent[0].role != "user":
            recent = recent[1:]
        return [{"role": m.role, "text": m.text} for m in recent]

    def recent(self, n: int = 10) -> list:
        return [m.to_dict() for m in self._messages[-n:]]

    def count(self) -> int:
        return len(self._messages)
