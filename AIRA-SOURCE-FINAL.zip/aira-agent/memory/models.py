"""Memory data models."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

ROLES = ("user", "assistant")
MAX_TEXT = 20000


class MemoryValidationError(ValueError):
    pass


@dataclass
class Message:
    role: str
    text: str
    ts: float = field(default_factory=time.time)

    def __post_init__(self):
        if self.role not in ROLES:
            raise MemoryValidationError(f"invalid role: {self.role!r}")
        if not isinstance(self.text, str):
            raise MemoryValidationError("text must be a string")
        if len(self.text) > MAX_TEXT:
            self.text = self.text[:MAX_TEXT]
        if isinstance(self.ts, bool) or not isinstance(self.ts, (int, float)):
            raise MemoryValidationError("ts must be a number")

    def to_dict(self) -> dict:
        return {"role": self.role, "text": self.text, "ts": self.ts}

    @classmethod
    def from_dict(cls, d) -> "Message":
        if not isinstance(d, dict):
            raise MemoryValidationError("message must be an object")
        text = d.get("text", d.get("content"))
        return cls(d.get("role"), text, d.get("ts", 0.0))
