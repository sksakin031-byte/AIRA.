#!/usr/bin/env bash
# AIRA setup: checks Python, prepares folders, keeps existing config/data untouched.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
info() { echo "[AIRA setup] $*"; }
err()  { echo "[AIRA setup] ERROR: $*" >&2; exit 1; }

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
[ -n "$PY" ] || err "Python not found. In Termux run: pkg install python"

"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' \
  || err "Python 3.10+ is required (found: $("$PY" --version 2>&1)). In Termux: pkg upgrade python"
info "Using $("$PY" --version 2>&1)"

mkdir -p workspace data
[ -e workspace/.gitkeep ] || : > workspace/.gitkeep

if [ -e config/settings.json ]; then
  info "config/settings.json exists - left unchanged."
else
  cp config/settings.example.json config/settings.json \
    || err "could not create config/settings.json"
  info "Created config/settings.json from the example."
fi

info "No third-party packages needed (requirements.txt is empty)."
"$PY" -m core.main --self-check || err "self-check failed - see message above."

echo
info "Setup complete. Next:"
info "  1) Store your Gemini key:  $PY scripts/set_key.py   (or: export GEMINI_API_KEY=...)"
info "  2) Start AIRA:             ./start.sh"
info "  3) Run offline tests:      ./test.sh"
