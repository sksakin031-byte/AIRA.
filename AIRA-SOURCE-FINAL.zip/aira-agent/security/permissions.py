"""Static operation classification. Unknown operations are denied."""
from __future__ import annotations

SENSITIVE = frozenset({"write_file", "run_tests"})
SAFE = frozenset({"list_files", "read_file", "validate_python", "project_structure"})


def classify(tool_name: str) -> str:
    """Return 'sensitive', 'safe' or 'unknown'. Decided here, never by the tool or the AI."""
    if tool_name in SENSITIVE:
        return "sensitive"
    if tool_name in SAFE:
        return "safe"
    return "unknown"
