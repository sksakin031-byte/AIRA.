"""Human approval layer. Default deny; only a human-input function can approve."""
from __future__ import annotations

import uuid
from dataclasses import dataclass

from core.i18n import t

YES = {"y", "yes", "হ্যাঁ", "হ্যা", "হাঁ", "হা"}


@dataclass(frozen=True)
class ApprovalRequest:
    action: str
    target: str
    details: str = ""
    request_id: str = ""

    @staticmethod
    def new(action: str, target: str, details: str = "") -> "ApprovalRequest":
        return ApprovalRequest(action, target, details, uuid.uuid4().hex[:8])


class DenyAllApprover:
    """Used whenever no human is available."""

    def request(self, req: ApprovalRequest) -> bool:
        return False


class Approver:
    """Asks the human at the terminal. Each request id can be decided exactly once."""

    def __init__(self, input_fn=input, output_fn=print, lang_fn=lambda: "bn"):
        self._input = input_fn
        self._output = output_fn
        self._lang = lang_fn
        self._decided: set = set()

    def request(self, req: ApprovalRequest) -> bool:
        if not req.request_id or req.request_id in self._decided:
            return False
        self._decided.add(req.request_id)
        lang = self._lang()
        self._output("")
        self._output(f"== {t(lang, 'approval_title')} [{req.request_id}] ==")
        self._output(f"{t(lang, 'action')}: {req.action}")
        self._output(f"{t(lang, 'target')}: {req.target}")
        if req.details:
            self._output(f"{t(lang, 'details')}: {req.details}")
        try:
            answer = self._input(t(lang, "approval_prompt"))
        except (EOFError, KeyboardInterrupt):
            return False
        return isinstance(answer, str) and answer.strip().lower() in YES
