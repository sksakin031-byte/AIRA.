"""Append-only JSONL audit log with secret redaction. Fails closed."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from security.secrets import redact


class AuditError(RuntimeError):
    pass


_SENSITIVE_KEYS = ("key", "token", "password", "secret", "authorization", "credential")


def _clean(value):
    if isinstance(value, str):
        return redact(value)[:500]
    if isinstance(value, dict):
        return {str(k): ("[REDACTED]" if any(w in str(k).lower() for w in _SENSITIVE_KEYS) else _clean(v))
                for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return redact(repr(value))[:500]


class AuditLog:
    def __init__(self, path):
        self.path = Path(path)

    def log(self, event: str, **fields) -> None:
        record = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "event": event}
        record.update(_clean(fields))
        line = json.dumps(record, ensure_ascii=False) + "\n"
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
            with os.fdopen(fd, "a", encoding="utf-8") as f:
                f.write(line)
        except OSError as exc:
            raise AuditError(f"audit log unavailable: {exc}") from exc
